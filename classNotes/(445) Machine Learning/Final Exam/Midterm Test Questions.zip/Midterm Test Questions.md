![[Pasted image 20240428231451.png]]

# Question 4 
![[Pasted image 20240428231535.png]]

![[3.png]]

![[Screenshot 2024-04-28 230830.png]]

![[Pasted image 20240428231845.png]]

![[5.png]]

![[Pasted image 20240428231932.png]]

![[Pasted image 20240428232040.png]]
![[Pasted image 20240428232058.png]]![[Pasted image 20240428232113.png]]![[Pasted image 20240428232128.png]]
![[Pasted image 20240428232138.png]]![[Pasted image 20240428232206.png]]![[Pasted image 20240428232228.png]]